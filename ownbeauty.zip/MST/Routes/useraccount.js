import a from "../controllers/account.js";
import express from "express";

const Routes = express.Router();

Routes.post("/", a.getUserDetails);
Routes.get("/signup", a.getSignup);
Routes.post("/signup", a.signupCheck);
Routes.get("/login", a.getLogin);
Routes.post("/login", a.loginCheck);

export default Routes;
