import a from "../controllers/admin.js";
import express from "express";

const Routes = express.Router();
Routes.get("/users", a.getUsers);
Routes.get("/bookings/appointments", a.getAppointBookings);
Routes.get("/bookings/homeservices", a.getHomeservicesBookings);
Routes.get("/reviews", a.getReviews);
Routes.get("/contactus", a.getContactUS);

export default Routes;
