import express from "express";
import a from "../controllers/contactus.js";

const Routes = express.Router();

Routes.post("/", a.handleContact);

export default Routes;
