import express from "express";
import a from "../controllers/reviews.js";

const Routes = express.Router();

Routes.post("/", a.handleReviews);
Routes.get("/", a.getReviews);

export default Routes;
