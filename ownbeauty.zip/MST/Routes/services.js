import express from "express";
import a from "../controllers/services.js";

const Routes = express.Router();

Routes.post("/appointment", a.requestAppointment);
Routes.post("/homeservices", a.requestHomeservices);

export default Routes;
