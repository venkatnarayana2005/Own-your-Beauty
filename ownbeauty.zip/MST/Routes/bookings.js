import a from "../controllers/bookings.js";
import express from "express";

const Routes = express.Router();

Routes.get("/:email", a.getUserBookings);
Routes.delete("/", a.deleteBooking);
export default Routes;
