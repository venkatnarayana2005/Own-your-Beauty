import mongoose from "mongoose";

const appointmentSchema = new mongoose.Schema({
  sname: {
    type: String,
    required: true,
    trim: true, // Removes whitespace from both ends of the string
  },
  email: {
    type: String,
    required: true,
    trim: true,
  },
  appointmentDate: {
    type: Date,
    required: true,
  },
  appointmentTime: {
    type: String,
    required: true,
    trim: true,
  },
  service: {
    type: String,
    required: true,
    trim: true,
    enum: [
      "HairCut",
      "Hair Treatments",
      "Hair Colours",
      "Skin Care",
      "Luxury Pedi/Mani",
      "Hair Spa",
      "Makeup",
      "Hair Setting",
      "Pre Bridal",
      "Skin/Face",
      "Rebonding",
      "Pedicure",
    ],
  },
  serviceType: {
    type: String,
    default: "appointment",
  },
  date: {
    type: Date,
    default: Date.now,
  },
});

export default mongoose.model("Appointment", appointmentSchema);
