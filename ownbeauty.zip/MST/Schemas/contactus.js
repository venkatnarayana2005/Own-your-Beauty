import mongoose from "mongoose";

// Define the Contact Schema
const contactSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true, // Removes whitespace from both ends
  },
  email: {
    type: String,
    required: true,
  },
  subject: {
    type: String,
    required: true,
    trim: true, // Removes whitespace from both ends
  },
  message: {
    type: String,
    required: true,
    minlength: 10, // Minimum length for the message
  },
});

// Create the Contact model
export default mongoose.model("Contact", contactSchema);
