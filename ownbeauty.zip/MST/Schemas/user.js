import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  fullname: { type: String, required: true },
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  number: { type: String, required: true },
  gender: { type: String, required: true },
  admin: { type: Boolean, default: "false" },
  reviews: {
    type: [mongoose.Schema.Types.ObjectId],
    ref: "reviews", // References the "reviews" collection
    default: [],
  },
  homeServiceBookings: {
    type: [mongoose.Schema.Types.ObjectId],
    ref: "Homeservices", // References the "homeservices" collection
    default: [],
  },
  appointmentBookings: {
    type: [mongoose.Schema.Types.ObjectId],
    ref: "Appointment", // References the "appointment" collection
    default: [],
  },
});

// Specify the collection name as 'registration28'
export default mongoose.model("User", userSchema);
