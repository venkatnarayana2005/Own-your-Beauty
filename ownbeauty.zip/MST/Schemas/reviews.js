import mongoose from "mongoose";

// Define the review schema
const reviewSchema = new mongoose.Schema(
  {
    reviewerName: {
      type: String,
      required: true,
      trim: true,
      index: true, // Index for faster searches
    },
    email: {
      type: String,
      required: true,
      match: /.+\@.+\..+/, // Simple regex for email validation
    },
    message: {
      type: String,
      required: true,
      minlength: 10,
      maxlength: 500,
    },
  },
  { timestamps: true }
); // Automatically manage createdAt and updatedAt

// Create a model from the schema
export default mongoose.model("Review", reviewSchema);
