import express from "express";
import Routes1 from "./Routes/useraccount.js";
import Routes2 from "./Routes/services.js";
import Routes3 from "./Routes/reviews.js";
import Routes4 from "./Routes/contactus.js";
import Routes5 from "./Routes/bookings.js";
import Routes6 from "./Routes/admin.js";
import bodyParser from "body-parser";
import configdatabase from "./database.js";
import path from "path";
import cors from "cors";
import { fileURLToPath } from "url";

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = 5000;

app.use(express.static(path.join(__dirname, "public")));
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use("/user", Routes1); //for user login ,signup,userdetails
app.use("/services", Routes2); // for booking appointment and homeservices
app.use("/reviews", Routes3); //for reviews
app.use("/contactus", Routes4); //for contact us
app.use("/bookings", Routes5); //for getting booking details of an user
app.use("/admin", Routes6); //for gettting details for admin

configdatabase(); // connecting mongodb

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html")); //for getting home page
});

app.get("/adminindex.html", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "adminindex.html"));
});
app.listen(PORT, (err) => {
  if (err) {
    console.error(err);
  }
  console.log(`server is running on localhost:${PORT}`);
});
