function handleLogout() {
  alert("Successfully logged out as admin");
  localStorage.removeItem("aemail");
  window.location.href = "adminindex.html"; // Redirect to home page
}

function toggleDropdown(event) {
  event.stopPropagation(); // Prevent event from bubbling up to document
  const dropdown = document.querySelector(".dropdown-content");
  dropdown.style.display =
    dropdown.style.display === "block" ? "none" : "block"; // Toggle dropdown
}
window.onload = () => {
  fetchUserDetails();
  fetchDetails();
};
async function fetchUserDetails() {
  const email = localStorage.getItem("aemail");
  const profileMenu = document.getElementById("profile-menu");
  const loginButton = document.getElementById("login-button");
  const welcomeMessage = document.getElementById("welcome-message"); // Reference for welcome message

  if (email) {
    try {
      const response = await fetch("http://localhost:5000/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.json();
      document.getElementById("fullname").textContent = data.fullname;
      document.getElementById("gender").textContent = data.gender;
      document.getElementById("email").textContent = data.email;
      profileMenu.style.display = "block"; // Show profile menu
      loginButton.style.display = "none"; // Hide login button
      welcomeMessage.textContent = `Welcome, ${data.fullname}`; // Update welcome message
    } catch (error) {
      console.error("There was a problem with the fetch operation:", error);
    }
  } else {
    // Clear dropdown if no email found
    document.getElementById("fullname").textContent = "";
    document.getElementById("gender").textContent = "";
    document.getElementById("email").textContent = "";
    profileMenu.style.display = "none"; // Hide profile menu
    loginButton.style.display = "block"; // Show login button
    welcomeMessage.textContent = ""; // Clear welcome message
  }
}

// Close dropdown if clicked outside
document.addEventListener("click", function () {
  const dropdown = document.querySelector(".dropdown-content");
  dropdown.style.display = "none"; // Hide dropdown
});
async function fetchDetails() {
  const email = localStorage.getItem("aemail");
  if (email) {
    try {
      const response = await fetch("http://localhost:5000/admin/users"); // Adjust the API endpoint as necessary
      if (!response.ok) throw new Error("Network response was not ok");
      const users = await response.json();

      const userTableBody = document.getElementById("user-table-body");
      userTableBody.innerHTML = ""; // Clear existing table rows

      users.forEach((user) => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${user.fullname}</td>
          <td>${user.email}</td>
          <td>${user.number}</td>
          <td>${user.gender}</td>
        `;
        userTableBody.appendChild(row);
      });
    } catch (error) {
      console.error("Error fetching user details:", error);
    }
  } else {
    const userTableBody = document.getElementById("user-table-body");
    userTableBody.innerHTML = "no users found";
  }
}

async function fetchAppointmentBookings() {
  const email = localStorage.getItem("aemail");
  const bookingTableBody = document.getElementById(
    "booking-table-body-appointments"
  );

  if (email) {
    try {
      const response = await fetch(
        "http://localhost:5000/admin/bookings/appointments"
      ); // Adjust the API endpoint as necessary
      if (!response.ok) throw new Error("Network response was not ok");
      const bookings = await response.json();
      console.log(bookings);
      bookingTableBody.innerHTML = ""; // Clear existing table rows

      if (bookings.length === 0) {
        // If there are no bookings, display a message
        bookingTableBody.innerHTML =
          "<tr><td colspan='5'>No appointments are booked.</td></tr>";
      } else {
        // Populate the table with booking details
        bookings.forEach((booking) => {
          const row = document.createElement("tr");
          row.innerHTML = `
              <td>${booking.sname}</td>
              <td>${booking.email}</td>
              <td>${booking.appointmentDate}</td>
              <td>${booking.appointmentTime}</td>
              <td>${booking.service}</td>
            `;
          bookingTableBody.appendChild(row);
        });
      }
    } catch (error) {
      console.error("Error fetching appointment bookings:", error);
      bookingTableBody.innerHTML =
        "<tr><td colspan='5'>Error fetching bookings</td></tr>";
    }
  } else {
    // Handle case when no email is found
    bookingTableBody.innerHTML =
      "<tr><td colspan='5'>No bookings found.</td></tr>";
  }
}

async function fetchHomeservicesBookings() {
  const email = localStorage.getItem("aemail");
  const bookingTableBody = document.getElementById(
    "booking-table-body-homeservices"
  );

  if (!bookingTableBody) {
    console.error(
      "Element with ID 'booking-table-body-homeservices' not found in DOM."
    );
    return;
  }

  if (email) {
    try {
      const response = await fetch(
        "http://localhost:5000/admin/bookings/homeservices"
      );
      if (!response.ok) throw new Error("Network response was not ok");
      const bookings = await response.json();

      bookingTableBody.innerHTML = ""; // Clear existing table rows

      if (bookings.length === 0) {
        bookingTableBody.innerHTML =
          "<tr><td colspan='8'>No home service bookings available.</td></tr>";
      } else {
        bookings.forEach((booking) => {
          const row = document.createElement("tr");
          row.innerHTML = `
              <td>${booking.sname}</td>
              <td>${booking.email}</td>
              <td>${booking.appointmentDate}</td>
              <td>${booking.appointmentTime}</td>
              <td>${booking.phone}</td>
              <td>${booking.gender}</td>
              <td>${booking.service}</td>
              <td>${booking.address}</td>
            `;
          bookingTableBody.appendChild(row);
        });
      }
    } catch (error) {
      console.error("Error fetching home services bookings:", error);
      bookingTableBody.innerHTML =
        "<tr><td colspan='8'>Error fetching bookings</td></tr>";
    }
  } else {
    bookingTableBody.innerHTML =
      "<tr><td colspan='8'>No bookings found</td></tr>";
  }
}

async function fetchReviews() {
  const email = localStorage.getItem("aemail");
  const reviewTableBody = document.getElementById("review-table-body");

  if (!reviewTableBody) {
    console.error("Element with ID 'review-table-body' not found in DOM.");
    return;
  }

  if (email) {
    try {
      const response = await fetch("http://localhost:5000/admin/reviews");
      if (!response.ok) throw new Error("Network response was not ok");
      const reviews = await response.json();

      reviewTableBody.innerHTML = ""; // Clear existing table rows

      if (reviews.length === 0) {
        reviewTableBody.innerHTML =
          "<tr><td colspan='3'>No reviews available.</td></tr>";
      } else {
        reviews.forEach((review) => {
          const row = document.createElement("tr");
          row.innerHTML = `
              <td>${review.reviewerName}</td>
              <td>${review.email}</td>
              <td>${review.message}</td>
            `;
          reviewTableBody.appendChild(row);
        });
      }
    } catch (error) {
      console.error("Error fetching reviews:", error);
      reviewTableBody.innerHTML =
        "<tr><td colspan='3'>Error fetching reviews</td></tr>";
    }
  } else {
    reviewTableBody.innerHTML =
      "<tr><td colspan='3'>No reviews found</td></tr>";
  }
}
async function fetchContactMessages() {
  const email = localStorage.getItem("aemail");
  const contactTableBody = document.getElementById("contact-table-body");

  if (!contactTableBody) {
    console.error("Element with ID 'contact-table-body' not found in DOM.");
    return;
  }

  if (email) {
    try {
      const response = await fetch("http://localhost:5000/admin/contactus");
      if (!response.ok) throw new Error("Network response was not ok");
      const contacts = await response.json();

      contactTableBody.innerHTML = ""; // Clear existing table rows

      if (contacts.length === 0) {
        contactTableBody.innerHTML =
          "<tr><td colspan='4'>No contact messages available.</td></tr>";
      } else {
        contacts.forEach((contact) => {
          const row = document.createElement("tr");
          row.innerHTML = `
              <td>${contact.name}</td>
              <td>${contact.email}</td>
              <td>${contact.subject}</td>
              <td>${contact.message}</td>
            `;
          contactTableBody.appendChild(row);
        });
      }
    } catch (error) {
      console.error("Error fetching contact messages:", error);
      contactTableBody.innerHTML =
        "<tr><td colspan='4'>Error fetching contact messages</td></tr>";
    }
  } else {
    contactTableBody.innerHTML =
      "<tr><td colspan='4'>No contact messages found</td></tr>";
  }
}
