async function showExtraContainer() {
  const email = localStorage.getItem("email");
  const bookingsList = document.getElementById("bookings-list");

  if (!email) {
    bookingsList.innerHTML = "<p>Please log in to see your bookings.</p>";
    document.getElementById("extra-container").style.display = "block";
    return;
  }

  try {
    const response = await fetch(`http://localhost:5000/bookings/${email}`);
    if (!response.ok) throw new Error("Network response was not ok");

    const bookings = await response.json();
    bookingsList.innerHTML = "";

    if (bookings.length === 0) {
      bookingsList.innerHTML = "<p>No bookings found.</p>";
    } else {
      bookings.forEach((booking) => {
        const bookingItem = document.createElement("div");
        bookingItem.className = "booking-item";

        const appointmentDate = booking.appointmentDate
          ? new Date(booking.appointmentDate).toLocaleDateString()
          : "N/A";
        const appointmentTime = booking.appointmentTime || "N/A";
        const serviceType = booking.service || "N/A";

        bookingItem.innerHTML = `
            <p><strong>Name:</strong> ${booking.sname || "N/A"}</p>
            <p><strong>Email:</strong> ${booking.email || "N/A"}</p>
            <p><strong>Type:</strong> ${booking.type || "N/A"}</p>
            <p><strong>Appointment Date:</strong> ${appointmentDate}</p>
            <p><strong>Appointment Time:</strong> ${appointmentTime}</p>
            <p><strong>Service:</strong> ${serviceType}</p>
          `;

        // Create a delete button
        const deleteBtn = document.createElement("button");
        deleteBtn.className = "delete-btn";
        deleteBtn.textContent = "Delete";
        deleteBtn.onclick = () =>
          deleteBooking(booking.type, booking._id, email);
        bookingItem.appendChild(deleteBtn);

        bookingsList.appendChild(bookingItem);
      });
    }

    document.getElementById("extra-container").style.display = "block";
  } catch (error) {
    console.error("Error fetching bookings:", error);
    bookingsList.innerHTML =
      "<p>Error fetching bookings. Please try again later.</p>";
  }
}

function hideExtraContainer() {
  document.getElementById("extra-container").style.display = "none";
}

function handleLogout() {
  alert("Successfully logged out");
  localStorage.removeItem("email");
  window.location.href = "/";
}

function toggleDropdown() {
  const dropdown = document.querySelector(".dropdown-content");
  dropdown.style.display =
    dropdown.style.display === "block" ? "none" : "block";
}

async function fetchUserDetails() {
  const email = localStorage.getItem("email");
  const profileMenu = document.getElementById("profile-menu");
  const loginButton = document.getElementById("login-button");
  const welcomeMessage = document.getElementById("welcome-message");
  if (email) {
    try {
      const response = await fetch("http://localhost:5000/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.json();
      document.getElementById("fullname").textContent = data.fullname;
      document.getElementById("gender").textContent = data.gender;
      document.getElementById("email").textContent = data.email;
      profileMenu.style.display = "block"; // Show profile menu
      loginButton.style.display = "none"; // Hide login button
      welcomeMessage.textContent = `Welcome, ${data.fullname}`;
    } catch (error) {
      console.error("There was a problem with the fetch operation:", error);
    }
  } else {
    // Clear dropdown if no email found
    document.getElementById("fullname").textContent = "";
    document.getElementById("gender").textContent = "";
    document.getElementById("email").textContent = "";
    profileMenu.style.display = "none"; // Hide profile menu
    loginButton.style.display = "block"; // Show login button
  }
}

// Execute fetchUserDetails when the page loads
window.onload = fetchUserDetails;

async function deleteBooking(type, id, email) {
  try {
    const response = await fetch("http://localhost:5000/bookings", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ type, id, email }),
    });

    if (response.ok) {
      const data = await response.json();
      alert(data.message);
      showExtraContainer(); // Refresh bookings
    } else {
      const errorData = await response.json();
      alert(errorData.message);
      console.error("Error:", errorData.message);
    }
  } catch (error) {
    console.error("Error:", error);
  }
}

// Event listener to hide dropdown if clicking outside of it
document.addEventListener("click", function (event) {
  const dropdown = document.querySelector(".dropdown-content");
  const profileMenu = document.getElementById("profile-menu");
  welcomeMessage.textContent = ""; // Clear welcome message
  // Check if the clicked element is outside the profile menu
  if (!profileMenu.contains(event.target)) {
    dropdown.style.display = "none"; // Hide dropdown
  }
});
