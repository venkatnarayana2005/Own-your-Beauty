import Appointment from "../Schemas/appointment.js";
import Homeservices from "../Schemas/homeservices.js";
import User from "../Schemas/user.js";

const MAX_BOOKINGS_PER_SLOT = 3; // Maximum number of bookings allowed per time slot

const requestAppointment = async (req, res) => {
  const { sname, email, appointmentDate, appointmentTime, service, useremail } = req.body;

  // Validate input data
  if (!sname || !email || !appointmentDate || !appointmentTime || !service) {
    return res.status(400).json({ message: "All fields are required." });
  }

  // Convert appointmentDate to Date object
  const dateObject = new Date(appointmentDate);
  if (isNaN(dateObject.getTime())) {
    return res.status(400).json({ message: "Invalid date provided." });
  }

  try {
    // Check existing appointments on the same date and time
    const existingAppointments = await Appointment.find({
      appointmentDate: dateObject,
      appointmentTime: appointmentTime
    });

    // If there are already the maximum allowed bookings for this time slot, return an error
    if (existingAppointments.length >= MAX_BOOKINGS_PER_SLOT) {
      return res.status(400).json({ message: "No booking available for this time slot." });
    }

    const newAppointment = new Appointment({
      sname,
      email,
      appointmentDate: dateObject,
      appointmentTime,
      service,
      useremail,
    });

    const nappointment = await newAppointment.save();

    const nuser = await User.findOne({ email: useremail });
    nuser.appointmentBookings.push(nappointment._id);
    await nuser.save();

    console.log("New appointment saved");
    res.status(201).json({ message: "Successfully submitted", redirectUrl: "/" });
  } catch (err) {
    console.error("Error saving appointment:", err);
    res.status(500).json({
      message: "Error occurred while saving appointment.",
      error: err.message,
      redirectUrl: "/homeservices",
    });
  }
};

const requestHomeservices = async (req, res) => {
  const {
    sname,
    email,
    phone,
    gender,
    appointmentDate,
    appointmentTime,
    address,
    service,
    useremail,
  } = req.body;

  // Validate input data
  if (!sname || !email || !phone || !gender || !appointmentDate || !appointmentTime || !address || !service) {
    return res.status(400).json({ message: "All fields are required." });
  }

  // Convert appointmentDate to Date object
  const dateObject = new Date(appointmentDate);
  if (isNaN(dateObject.getTime())) {
    return res.status(400).json({ message: "Invalid date provided." });
  }

  try {
    // Check existing home services on the same date and time
    const existingHomeservices = await Homeservices.find({
      appointmentDate: dateObject,
      appointmentTime: appointmentTime
    });

    // If there are already the maximum allowed bookings for this time slot, return an error
    if (existingHomeservices.length >= MAX_BOOKINGS_PER_SLOT) {
      return res.status(400).json({ message: "No booking available for this time. Please kindly request to book another slot." });
    }

    const newService = new Homeservices({
      sname,
      email,
      phone,
      gender,
      appointmentDate: dateObject,
      appointmentTime,
      address,
      service,
    });

    const nhomeservice = await newService.save();
    const nuser = await User.findOne({ email: useremail });
    nuser.homeServiceBookings.push(nhomeservice._id);
    await nuser.save();

    console.log("Saved one home service booking");
    res.status(201).json({
      message: "Successfully submitted",
      redirect: "/",
    });
  } catch (error) {
    console.error("Error saving homeservices:", error);
    res.status(500).json({ message: "Error occurred while saving home service.", error: error.message, redirect: "/homeservices" });
  }
};

const a = { requestAppointment, requestHomeservices };
export default a;