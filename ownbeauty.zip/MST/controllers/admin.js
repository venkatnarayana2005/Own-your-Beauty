import User from "../Schemas/user.js";
import Appointment from "../Schemas/appointment.js";
import Homeservices from "../Schemas/homeservices.js";
import Reviews from "../Schemas/reviews.js";
import Contactus from "../Schemas/contactus.js";

const getUsers = async (req, res) => {
  try {
    const users = await User.find({ admin: false }).select(
      "fullname email number gender"
    );
    console.log(users);
    res.status(200).json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error fetching users" });
  }
};

const getAppointBookings = async (req, res) => {
  try {
    const bookings = await Appointment.find().select(
      "sname email appointmentDate  appointmentTime service"
    );
    console.log(bookings, "bookings");
    res.status(200).json(bookings);
  } catch (err) {
    console.log("error occur", err.message);
    res.status(500).json({ message: "internal server error" + err.message });
  }
};

const getHomeservicesBookings = async (req, res) => {
  try {
    const bookings = await Homeservices.find().select(
      "sname email appointmentDate appointmentTime phone gender service address"
    );
    console.log(bookings);
    res.status(200).json(bookings);
  } catch (err) {
    console.log("error occur", err.message);
    res.status(500).json({ message: "internal server error" + err.message });
  }
};

const getReviews = async (req, res) => {
  try {
    const reviews = await Reviews.find().select("reviewerName email message");
    res.status(200).json(reviews);
  } catch (err) {
    console.log("error occur", err.message);
    res.status(500).json({ message: "internal server error" + err.message });
  }
};

const getContactUS = async (req, res) => {
  try {
    const contact = await Contactus.find().select("name email subject message");
    res.status(200).json(contact);
  } catch (err) {
    console.log("error occur", err.message);
    res.status(500).json({ message: "internal server error" + err.message });
  }
};

const a = {
  getUsers,
  getAppointBookings,
  getHomeservicesBookings,
  getReviews,
  getContactUS,
};

export default a;
