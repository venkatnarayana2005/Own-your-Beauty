import User from "../Schemas/user.js";
import appointment from "../Schemas/appointment.js";
import homeservices from "../Schemas/homeservices.js";

const getUserBookings = async (req, res) => {
  try {
    const { email } = req.params;

    // Find the user by email and populate the necessary booking fields
    const user = await User.findOne({ email })
      .populate("homeServiceBookings")
      .populate("appointmentBookings");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Merge both bookings into one array with distinct date fields
    const allBookings = [
      ...user.homeServiceBookings.map((service) => ({
        ...service.toObject(),
        type: "homeService",
        date: service.appointmentDate, // Use `appointmentDate` for home services
      })),
      ...user.appointmentBookings.map((appointment) => ({
        ...appointment.toObject(),
        type: "appointment",
        date: appointment.date || appointment.appointmentDate, // Use `date` or `appointmentDate` for appointments
      })),
    ];

    // Sort all bookings by the standardized `date` field in descending order
    const sortedBookings = allBookings.sort(
      (a, b) => new Date(b.date) - new Date(a.date)
    );

    console.log("Sorted Bookings:", sortedBookings);
    return res.status(200).json(sortedBookings);
  } catch (error) {
    console.error("Error fetching bookings:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

const deleteBooking = async (req, res) => {
  console.log("Deleting the booking", req.body);
  const { type, id, email } = req.body;

  try {
    const user = await User.findOne({ email: email });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (type == "appointment") {
      // Delete appointment booking from Appointment collection
      const appointmentBooking = await appointment.findByIdAndDelete(id);
      if (!appointmentBooking) {
        return res
          .status(404)
          .json({ message: "Appointment booking not found" });
      }

      // Remove booking reference from user's appointmentBookings array
      user.appointmentBookings = user.appointmentBookings.filter(
        (bookingId) => bookingId.toString() !== id
      );
      await user.save();

      res
        .status(200)
        .json({ message: "Successfully deleted appointment booking" });
    } else if (type == "homeService") {
      // Delete home service booking from Homeservices collection
      const homeServiceBooking = await homeservices.findByIdAndDelete(id);
      if (!homeServiceBooking) {
        return res
          .status(404)
          .json({ message: "Home service booking not found" });
      }

      // Remove booking reference from user's homeServiceBookings array
      user.homeServiceBookings = user.homeServiceBookings.filter(
        (bookingId) => bookingId.toString() !== id
      );
      await user.save();

      res
        .status(200)
        .json({ message: "Successfully deleted home service booking" });
    } else {
      res.status(400).json({ message: "Invalid booking type" });
    }
  } catch (error) {
    console.error("Error deleting booking:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const a = { getUserBookings, deleteBooking };
export default a;
