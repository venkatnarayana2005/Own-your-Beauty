import Reviews from "../Schemas/reviews.js";
import User from "../Schemas/user.js";

const handleReviews = async (req, res) => {
  const { reviewerName, email, message, useremail } = req.body;

  if (!reviewerName || !email || !message || message.length < 10) {
    console.log(typeof message);
    return res.status(400).json({ message: "Invalid input" });
  }

  try {
    const newReview = new Reviews({
      reviewerName,
      email,
      message,
    });

    const nreview = await newReview.save();
    const nuser = await User.findOne({ email: useremail });
    nuser.reviews.push(nreview._id);
    await nuser.save();
    console.log("Successfully submitted the review");
    res.status(201).json({ message: "Successfully submitted" });
  } catch (err) {
    console.error("Error submitting review:", err.message);
    res.status(400).json({ message: "Error occurred", error: err.message });
  }
};

const getReviews = async (req, res) => {
  try {
    const reviews = await Reviews.find().select("reviewerName message");
    res.status(200).json(reviews);
  } catch (err) {
    console.error("Error fetching reviews:", err.message);
    res.status(500).json({ message: "internal server error " + err.message });
  }
};
const a = { handleReviews, getReviews };
export default a;
