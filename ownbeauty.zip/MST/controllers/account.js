import User from "../Schemas/user.js";
import path from "path";

const getSignup = async (req, res) => {
  res.sendFile(path.join(__dirname, "public", "registration.html"));
};

const signupCheck = async (req, res) => {
  const { fullname, email, password, number, gender } = req.body;
  const n = await User.findOne({ email: email });
  if (n) {
    res.status(400).json({
      message: "user email already exist",
    });
  } else {
    const newUser = new User({
      fullname,
      email,
      password,
      number,
      gender,
    });

    try {
      await newUser.save(); // Save the user to the database
      console.log("User successfully saved to database");
      res.status(201).json({
        message: "Registration successful",
        redirectUrl: "/login.html",
      });
    } catch (error) {
      console.log("Error saving user:", error);
      res.status(400).json({
        message: "Error registering user: " + error,
      });
    }
  }
};

const getLogin = async (req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"));
};

const loginCheck = async (req, res) => {
  const { username, password } = req.body;
  const newuser = await User.findOne({ email: username });

  if (!newuser) {
    return res
      .status(400)
      .json({ message: "User not found", redirectUrl: "/login.html" });
  }

  // Assuming you are using bcrypt for password hashing

  if (newuser.password === password && !newuser.admin) {
    return res.status(200).json({
      message: "Login successfully",
      redirectUrl: "/",
      usertype: "user",
    });
  } else if (newuser.password && newuser.admin) {
    return res.status(200).json({
      message: "Login successfully as admin",
      redirectUrl: "/adminindex.html",
      usertype: "admin",
    });
  } else {
    return res.status(400).json({
      message: "Incorrect password, please enter the correct password",
      redirectUrl: "/login.html",
    });
  }
};

const getUserDetails = async (req, res) => {
  const { email } = req.body;

  // Try to find the user in the database
  const nuser = await User.findOne({ email: email });

  // Check if the user was found
  if (!nuser) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Return user details if found
  res.status(200).json({
    fullname: nuser.fullname,
    gender: nuser.gender,
    email: nuser.email,
  });

  console.log("Request for user details");
};


const a = { signupCheck, loginCheck, getLogin, getSignup, getUserDetails };

export default a;
