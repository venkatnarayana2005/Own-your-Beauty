import Contact from "../Schemas/contactus.js";

const handleContact = async (req, res) => {
  const { name, email, subject, message } = req.body;

  if (!name || !email || !subject || !message || message.length < 10) {
    console.log(typeof message);
    return res.status(400).json({ message: "Invalid input" });
  }

  try {
    const newContact = new Contact({
      name,
      email,
      subject,
      message,
    });

    await newContact.save();
    console.log("Successfully submitted the contact us");
    res
      .status(201)
      .json({ message: "Successfully submitted", redirectUrl: "/" });
  } catch (err) {
    console.error("Error submitting contact:", err.message);
    res.status(400).json({ message: "Error occurred", error: err.message });
  }
};

export default { handleContact };
